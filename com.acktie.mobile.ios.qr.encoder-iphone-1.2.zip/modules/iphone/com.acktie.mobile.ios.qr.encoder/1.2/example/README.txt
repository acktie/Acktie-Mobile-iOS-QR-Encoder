A fully working example for this module is available on github at https://github.com/acktie/Acktie-Mobile-QR-Encoder-Example

Tony Nuzzi @ Acktie

Twitter: @Acktie

Email: support@acktie.com